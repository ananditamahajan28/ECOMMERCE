const http = require('http');
const fs = require('fs');

const server = http.createServer((req,res)=>{
    if(req.url=== '/'){
        fs.readFile('products.json', 'utf-8', (err, data)=>{
            if(err){
                res.writeHead(500, {'Content-Type' : 'text/plain'});
                res.end('Internal Server Error');
                return;
            }
            const products = JSON.parse(data);
            const urlParams= new URLSearchParams(req.url.split('?')[1]);
            const category = urlParams.get('category');
            if(category){
                const filteredProducts= products.filter(product=> product.category === category);
                res.writeHead(200, {'Content-Type' : 'application/json'});
                res.end(JSON.stringify(filteredProducts));
            }
            else{
                res.writeHead(200, {'Content-Type' : 'application/json'});
                res.end(data);
            }
        });
    }
});
server.listen(3001, (err) => {
    if(err){
        console.log('Unable to start server:' , err);
    }
    else{
        console.log('Server started...');
    }
})
